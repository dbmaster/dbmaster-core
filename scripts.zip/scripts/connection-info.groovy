def serverInfo = connection.getCustomData("ServerInfo")
extra_info = ""
if (serverInfo == null) {
   extra_info = "run 'Import Server Info' to get detailed information. available only for sql server"
} else {
    def slurper = new XmlSlurper()
    def xmlServerInfo = slurper.parseText(serverInfo)

    extra_info = "<table cellspacing=\"10\" cellpadding=\"10\"><tr><td colspan=\"3\"><pre>"+xmlServerInfo.Version.text()+"</pre></td></tr><tr valign=\"top\"><td>"
    extra_info += "<h2>Configuration Parameters</h2><table class=\"simple-table\" cellspacing=\"0\" cellpadding=\"10\">";
    extra_info += "<tr style=\"background-color:#EEE\"><td>Parameter</td><td>Value</td></tr>";
    xmlServerInfo.Configuration.Config.each { config ->
        extra_info += "<tr><td>" + config.name.text() + "</td><td>" + config.value.text()+"</td></tr>";
    }
    extra_info += "</table></td><td>";
    extra_info += "<h2>Server Properties</h2><table class=\"simple-table\" cellspacing=\"0\" cellpadding=\"10\">";
    extra_info += "<tr style=\"background-color:#EEE\"><td>Property</td><td>Value</td></tr>";

    xmlServerInfo.Properties.Properties.children().each { p ->
	extra_info += "<tr><td>" + p.name() + "</td><td>" + p.text()+"</td></tr>";
    }

    extra_info += "</table></td><td>";
    extra_info += "<h2>System Info</h2><table class=\"simple-table\" cellspacing=\"0\" cellpadding=\"10\">";
    extra_info += "<tr style=\"background-color:#EEE\"><td>Item</td><td>Value</td></tr>";

    xmlServerInfo.SysInfo.SysInfo.children().each { p ->
	extra_info += "<tr><td>" + p.name() + "</td><td>" + p.text()+"</td></tr>";
    }

    extra_info += "</table>";
    extra_info += "</td></tr><table>"
}