import static com.branegy.util.IOUtils.toFileSize;

def dbDefinition = database.getCustomData("DatabaseDefinition")
extra_info = ""
if (dbDefinition == null) {
    extra_info = "run 'Import Server Info' to get detailed information. available only for sql server"
 } else {
     def slurper = new XmlSlurper()
     def xmlServerInfo = slurper.parseText(dbDefinition)
 
     extra_info = "<table cellspacing=\"10\" cellpadding=\"10\"><tr valign=\"top\"><td>"
     extra_info += "<h2>Properties</h2><table class=\"simple-table\" cellspacing=\"0\" cellpadding=\"10\">";
     extra_info += "<tr style=\"background-color:#EEE\"><td>Parameter</td><td>Value</td></tr>";
     xmlServerInfo.Properties.children().each { config ->
         extra_info += "<tr><td>" + config.name() + "</td><td>" + config.text()+"</td></tr>";
     }
     extra_info += "</table></td><td>";
     extra_info += "<h2>Database Files</h2><table class=\"simple-table\" cellspacing=\"0\" cellpadding=\"10\">";
     extra_info += """<tr style=\"background-color:#EEE\">
                <td>Logical Name</td>
                <td>File Type</td>
                <td>Size</td>
                <td>Max Size</td>
                <td>Grows</td>
                <td>Physical File Name</td>
                <td>State</td>
                <td>ReadOnly</td>
                </tr>"""
 
     xmlServerInfo.Files.File.each { file ->
         /**
            if (is_percent_growth  = 1 ) {
              grows + "%"
            } else {
             toSize(grows * 8Kb) 
            }  
          */
         extra_info += """<tr>
                 <td>${file.name.text()}</td>
                 <td>${file.type_desc.text()}</td>
                 <td style="text-align:right"></td>
                 <td style="text-align:right">${file.max_size.text()=="-1"?"Unlimited"
                                                                          :toFileSize(file.max_size.toBigInteger().multiply(BigInteger.valueOf(8*1024)))}</td>
                 <td style="text-align:right">${file.growth.text() == "0"? "None"
                                                : file.is_percent_growth.text()=="1" ? file.growth.text()+"%"
                                                                                     : toFileSize(file.growth.toBigInteger().multiply(BigInteger.valueOf(8*1024)))}</td>
                 <td>${file.physical_name.text()}</td>
                 <td>${file.state_desc.text()}</td>
                 <td>${file.is_read_only.text() == "0"?"No":"Yes"}</td>
            </tr>""";
     }
 
     extra_info += "</table></td>";
     extra_info += "</tr><table>"
 }
 