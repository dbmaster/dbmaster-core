def jobDefinition = job.getCustomData("JobDefinition")
extra_info = ""
if (jobDefinition == null) {
   extra_info = "run 'Import Server Info' to get detailed information. available only for sql server"
} else {
    def slurper = new XmlSlurper()
    def xmlServerInfo = slurper.parseText(jobDefinition)
    extra_info += "<h2>Job Attributes</h2><table class=\"simple-table\" cellspacing=\"0\" cellpadding=\"10\">";
    extra_info += "<tr style=\"background-color:#EEE\"><td>Parameter</td><td>Value</td></tr>";

    extra_info += "<tr><td>Server Name</td><td>${job.getServerName()}</td></tr>";
    extra_info += "<tr><td>Name</td><td>${job.getJobName()}</td></tr>";
    extra_info += "<tr><td>Job Id</td><td>${job.getCustomData("JobId")}</td></tr>";
    extra_info += "<tr><td>Enabled</td><td>${job.getCustomData("Enabled")}</td></tr>";
    extra_info += "<tr><td>Category</td><td>${job.getCustomData("Category")}</td></tr>";
    extra_info += "<tr><td>Description</td><td>${job.getCustomData("Description")}</td></tr>";
    extra_info += "<tr><td>Owner</td><td>${job.getCustomData("Owner")}</td></tr>";

    xmlServerInfo.children().each { attribute ->
        if (attribute.children().size()==0) {
            extra_info += "<tr><td>" + attribute.name() + "</td><td>" + attribute.text()+"</td></tr>";
        }
    }
    extra_info += "</table><br/>";

    extra_info += "<h2>Job Steps</h2>"

    def steps = xmlServerInfo.Steps.Step
    def describeAction = { action, stepId, jobSteps ->
        if (action.equals("3")) {
            return "Go to next step"
        } else if (action.equals("2")) {
            return "Quit with failure"
        } else if (action.equals("1")) {
            return "Quit with success"
        } else if (action.equals("4")) {
            def targetStep = jobSteps.find { s -> s.step_id.text().equals(stepId) } 
            return "Go to step " + (targetStep==null ? stepId : "'"+targetStep.step_name.text()+"'")
        } else {
            return action
        }
    }
    
    if (steps.size()==0) {
        extra_info += "the job has no steps"
    } else {
        extra_info += "<table class=\"simple-table\" cellspacing=\"0\" cellpadding=\"10\">"
        extra_info += """<tr style=\"background-color:#EEE\">
                <td>Id</td>
                <td>Name</td>
                <td>Type</td>
                <td>Success Code</td>
                <td>On Success Action</td>
                <td>On Failure Action</td>
                <td>Database</td>
                <td>Run As</td>
                <td>Retry Attempts</td>
                <td>Retry Interval(minutes)</td>
                <td>Output File</td>
                </tr>"""
            
        steps.each { step ->
            def subsystem = step.subsystem.text()
            extra_info += """<tr>
                            <td>Step ${step.step_id.text()}</td>
                            <td>${step.step_name.text()}</td>
                            <td>${subsystem}</td>
                            <td>${if (subsystem.equals("CmdExec")) step.cmdexec_success_code.text() else ""}</td>                            
                            <td>${describeAction(step.on_success_action.text(), step.on_success_step_id.text(),steps)}</td>
                            <td>${describeAction(step.on_fail_action.text(), step.on_fail_step_id.text(),steps)}</td>
                            <td>${step.database_name.text()}</td>
                            <td>${step.database_user_name.text()}</td>
                            <td>${step.retry_attempts.text()}</td>
                            <td>${step.retry_interval.text()}</td>
                            <td>${step.output_file_name.text()}</td>
                            </tr>""";
            extra_info += """<tr><td colspan="15"><pre${subsystem=="CmdExec"?" class=\"brush: bash\"":
                                                        subsystem=="TSQL"   ?" class=\"brush: sql\"" :
                                                                                                      ""
                                                                      }>${step.command.text()}</pre></td></tr>"""
        }
        extra_info += "</table>"
    }

    extra_info += "<br/><h2>Schedules</h2>"
    def schedules = xmlServerInfo.Schedules.Schedule
    if (schedules.size()==0) {
        extra_info += "the job is not scheduled in sql server agent"
    } else {    
        extra_info += "<table class=\"simple-table\" cellspacing=\"0\" cellpadding=\"10\">"
        extra_info += """<tr style=\"background-color:#EEE\">
                <td>Schedule Id</td>
                <td>Name</td>
                <td>Enabled</td>
                <td>Summary</td>
                <td>Created</td>
                <td>Modified</td>
                <td>Version</td>
            </tr>"""

        
        schedules.each { s ->
            extra_info += """<tr>
                            <td>${s.schedule_id.text()}</td>
                            <td>${s.name.text()}</td>
                            <td>${s.enabled.text().equals("1") ? "Yes" : "No" }</td>
                            <td>${SQLServerDialect.getScheduleSummary(s)}</td>
                            <td>${s.date_created.text()}</td>
                            <td>${s.date_modified.text()}</td>
                            <td>${s.version_number.text()}</td>
                            </tr>""";
                            
        }
        extra_info += "</table>"
    }
    extra_info += "<br/><br/>"
}