extra_info = application.getCustomData("LDAPObjects")
if (extra_info== null) {
   extra_info = "No LDAP Objects defined for application ${application.getApplicationName()}"
}
extra_info = """<div style="margin:3px" class="x-form-field">${extra_info}</div>""".toString()