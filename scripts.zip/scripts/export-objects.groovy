import org.apache.poi.ss.usermodel.Sheet
import org.apache.poi.ss.usermodel.Workbook
import org.apache.poi.ss.usermodel.WorkbookFactory

import com.branegy.service.connection.model.DatabaseConnection;
import com.branegy.service.core.QueryRequest
import com.branegy.dbmaster.connection.DriverInfo;
import com.branegy.export.poi.ExcelHelper

def list;

QueryRequest queryRequest = new QueryRequest(query);
if (orderBy!=null){
    queryRequest.addOrderField(orderBy);
}
boolean databases = false;
boolean connections = false;
Map<String,DriverInfo> id2driver = null;
Set<String> driverProperties = null;
if ("servers".equals(type)) {
    list = invService.getServerList(queryRequest)
} else if ("applications".equals(type)){
    list = invService.getApplicationList(queryRequest)
} else if ("jobs".equals(type)){
    list = invService.getJobList(queryRequest)
} else if ("securityobjects".equals(type)){
    list = invService.getSecurityObjectList(queryRequest)
} else if ("databases".equals(type)){
    databases = true;
    list = invService.getDatabaseList(queryRequest)
} else if ("contacts".equals(type)){
    list = contactService.getContactList(queryRequest)
} else if ("custom-objects".equals(type)){
    list = objectService.getCustomObjectSlice(objectType,queryRequest)
} else if ("connections".equals(type)) {
    connections = true;
    list = connectionService.getConnectionSlice(queryRequest, null)
    // collect all drivers
    Set<String> drivers = [] as Set;
    list.each{ c ->
        drivers.add(c.getDriver());
    }
    
    id2driver = [:];
    connectionService.getDriverList().each {
        id2driver.put(it.getId(), it)
    }
    
    driverProperties = new LinkedHashSet<String>();
    drivers.each{ d ->
       DriverInfo driver = id2driver.get(d);
       if (driver!=null){
           driver.getProperties().eachWithIndex{ p, i ->
               driverProperties.add(p.getKey());
           }
       }
    }
    
    columns = new ArrayList<String>(Arrays.asList(columns));
    Collections.replaceAll(columns, "Url", "Connection URL")
    Collections.replaceAll(columns, "Name", "Connection Name")
    columns.addAll(driverProperties);
    columns = columns.toArray(new String[0]);
} else {
    throw new java.lang.IllegalArgumentException(type)
}

def workBook = WorkbookFactory.create(templateInputStream)
def sheet = workBook.getSheet(type);
if ("custom-objects".equals(type)){
    if (sheet == null){
        sheet = workBook.getSheet(objectType.toLowerCase());
        if (sheet == null){
            sheet = workBook.createSheet(objectType);
        }
    } else {
        workBook.setSheetName(workBook.getSheetIndex(sheet),objectType);
    }
}

def float_style = workBook.createCellStyle()
def float_format = workBook.createDataFormat().getFormat("0.0")
float_style.setDataFormat(float_format)

def date_style = workBook.createCellStyle()
def date_format = workBook.createDataFormat().getFormat("mm/dd/yyyy")
date_style.setDataFormat(date_format)

ExcelHelper.setHeader(sheet, null, null, columns)

def i=1;
Object val;

for (obj in list) {
    def row = sheet.getRow(i);
    if (row==null) {
        row = sheet.createRow(i);
    }
    for (int j=0; j<columns.length; ++j){
        if (columns[j] == "Last Change Date"){
            val = obj.getUpdated();
        } else if (connections && columns[j] == "Connection Name"){
            val = obj.getName();
        } else if (connections && columns[j] == "Driver"){
             val = id2driver.get(obj.getDriver())?.getName();
             if (val == null){
                 val = obj.getDriver();
             }
        } else if (connections && columns[j] == "User"){
            val = obj.getUsername();
        } else if (connections && columns[j] == "Connection URL"){
            val = obj.getUrl();
        } else if (connections && driverProperties.contains(columns[j])){
            val = id2driver.get(obj.getDriver());
            if (val != null){
                val = val.getProperties().findResult{ it.getKey() == columns[j] ? it : null }?.getValue();
            }
        } else if (databases && columns[j] == "ConnectionName"){
            val = obj.getConnectionName();
        } else if (connections && columns[j] == "Disabled"){
            val = obj.isDisabled();
        } else {
            val = obj.getCustomData(columns[j]);
        } 
        def cell = ExcelHelper.setCellValue(row, j, val)
        if (val instanceof java.util.Date) {
            cell.setCellStyle(date_style)
        }
        if (val instanceof Double || val instanceof Float || val instanceof java.math.BigDecimal) {
            cell.setCellStyle(float_style)
        }
    }
    i++;
}
workBook.write(outputStream)