import com.branegy.dbmaster.sync.api.SyncService
import com.branegy.service.core.QueryRequest
import com.branegy.dbmaster.sync.api.SyncPair

def serverName  = database.getServerName()
def dbName      = database.getDatabaseName()

SyncService syncService = dbm.getService(SyncService.class)

def generator = syncService.getSummaryGenerator("/db-sync-summary.groovy")
def pairs     = syncService.getSyncPairsByName("Server", serverName, "Database", dbName)

history_info  = "<h2>Synchronization History</h2>"
history_info += "<table class=\"simple-table\" cellspacing=\"0\" cellpadding=\"10\">";
history_info += "<tr style=\"background-color:#EEE\"><td>Date</td><td>Change Summary</td></tr>";

pairs.sort{ a,b-> b.syncDate<=>a.syncDate}.each { p ->
    if (p.getChangeType() != SyncPair.ChangeType.EQUALS) {
    	summary = generator.generateSummary(p)
        history_info += "<tr><td style=\"vertical-align:top\">${p.syncDate}</td><td>${summary}</td></tr>";
    }
}
history_info += "</table><br/><br/>";