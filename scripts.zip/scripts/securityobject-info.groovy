/* 
 *  File Version:  $Id: application-info.groovy 1871 2013-04-25 21:58:19Z schristin $
 */

extra_info = Math.random()+"";