def definition = securityobject.getCustomData("Definition")
extra_info = "xxl"

if (definition == null) {
    extra_info = "TODO"
} else {

     def slurper = new XmlSlurper()
     def xmlDefinition = slurper.parseText(definition)

     extra_info = "<h2>Server Permission</h2><table class=\"simple-table\" cellspacing=\"0\" cellpadding=\"10\">";
     extra_info += """<tr style=\"background-color:#EEE\">
                <td>Class</td>
                <td>Permission</td>
                <td>Endpoint Name</td>
                </tr>"""

     xmlDefinition.ServerPermissions.ServerPermission.each { p ->
         extra_info += """<tr><td>${p?.class_desc.text()?:""}</td><td>${p.state_desc.text()} ${p.permission_name.text()} </td><td>${p.EndpointName?.text()?:""}</td></tr>"""
     }
     extra_info += "</table>";
}