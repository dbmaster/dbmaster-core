import com.branegy.email.EmailSender;

import com.google.inject.Key;
import com.google.inject.name.Names;

import com.branegy.gwt.service.impl.WebSecurityUtil;
import com.branegy.tools.api.ToolService;
import com.branegy.tools.model.ToolHistory;

String url = injector.getInstance(Key.get(String.class, Names.named(WebSecurityUtil.DBMASTER_URL)))
    .concat("#")
    .concat("INVENTORY".equals(ctx.getCurrentProject().getType())?"inventory":"dictionary")
    .concat("/project:")
    .concat(ctx.getCurrentProject().getName())
    .concat("/tools/history/execution-id:${executionId}");

ToolHistory history = injector.getInstance(ToolService.class).findToolHistoryById(executionId, null);
String toolName = history.getToolName();    
Date time = history.getStart();

Iterator<String> it = emails.iterator();
EmailSender email = injector.getInstance(EmailSender.class);
email.createHtmlMessage(it.next(),"Tool ${toolName} is completed successfully", 
    "Tool was started at ${time.format('M-d-yyyy KK:mm a')} by the scheduler.<br/>" +
    "Access results of the execution <a href=\"${url}\">here</a>.",false);

while (it.hasNext()){
    email.addRecepient(javax.mail.Message.RecipientType.TO,it.next());
}

email.sendMessage();